package com.example.videoplayer.EyeDetection;
public enum Condition {
    USER_EYES_OPEN, USER_EYES_CLOSED, FACE_NOT_FOUND
}
