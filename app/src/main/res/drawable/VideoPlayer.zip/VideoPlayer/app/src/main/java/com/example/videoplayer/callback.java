package com.example.videoplayer;

import com.example.videoplayer.Model.VideoFiles;

public interface callback {
        void onIconMoreClick(int position);


}
